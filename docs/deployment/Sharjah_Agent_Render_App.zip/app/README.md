# Airport Operations Assistant (Sharjah workshop) - Render app

Gemini + LlamaIndex agent with two tools (RAG on the PDFs in `data/pdfs`, read-only SQL on `data/airport_ops.zip`) and a Gradio page.

Render settings: Python 3 | Build `pip install -r requirements.txt` | Start `python app.py`
Environment variables: `GEMINI_API_KEY` (required), `APP_PASSWORD` (optional; user name `workshop`),
`LLM_MODEL` (default `gemini-3.5-flash`), `THINKING_LEVEL` (default `low`; empty = model default), `EMBED_MODEL` (default `gemini-embedding-001`).

To change the data: replace the PDFs in `data/pdfs/`, or replace `data/airport_ops.zip` with a zip containing one `.db` file. Never commit an API key.
