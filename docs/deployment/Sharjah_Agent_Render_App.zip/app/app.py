"""Airport Operations Assistant: a Gemini + LlamaIndex agent (RAG tool + SQL tool) with a Gradio page, for Render."""
import os
import sqlite3
import zipfile
from pathlib import Path

import gradio as gr
import pandas as pd
from google.genai import types
from google.genai.types import EmbedContentConfig
from llama_index.core import PromptTemplate, Settings, SimpleDirectoryReader, VectorStoreIndex
from llama_index.core.agent.workflow import FunctionAgent, ToolCall
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.tools import FunctionTool, QueryEngineTool
from llama_index.embeddings.google_genai import GoogleGenAIEmbedding
from llama_index.llms.google_genai import GoogleGenAI

# ------------------------------------------------------------------ settings (environment variables)
API_KEY = os.environ.get("GEMINI_API_KEY")
if not API_KEY:
    raise RuntimeError("GEMINI_API_KEY is not set. Add it under Environment in the Render dashboard.")

LLM_MODEL = os.environ.get("LLM_MODEL", "gemini-3.5-flash")
EMBED_MODEL = os.environ.get("EMBED_MODEL", "gemini-embedding-001")
THINKING_LEVEL = os.environ.get("THINKING_LEVEL", "low")        # minimal | low | medium | high | (empty = model default)
APP_PASSWORD = os.environ.get("APP_PASSWORD")                    # optional; user name is "workshop"
PORT = int(os.environ.get("PORT", "7860"))                       # Render sets PORT

BASE = Path(__file__).resolve().parent
PDF_FOLDER = BASE / "data" / "pdfs"
DB_ZIP = BASE / "data" / "airport_ops.zip"
DB_PATH = Path("/tmp/airport_ops.db")                            # the unzipped copy lives in /tmp

# ------------------------------------------------------------------ models
generation_config = None
if THINKING_LEVEL:
    generation_config = types.GenerateContentConfig(
        thinking_config=types.ThinkingConfig(thinking_level=THINKING_LEVEL)
    )

llm = GoogleGenAI(model=LLM_MODEL, api_key=API_KEY, generation_config=generation_config)
Settings.llm = llm
Settings.embed_model = GoogleGenAIEmbedding(
    model_name=EMBED_MODEL,
    api_key=API_KEY,
    embedding_config=EmbedContentConfig(output_dimensionality=768),
)

# ------------------------------------------------------------------ tool 1: RAG on the PDFs in data/pdfs
documents = SimpleDirectoryReader(input_dir=str(PDF_FOLDER), required_exts=[".pdf"]).load_data()
index = VectorStoreIndex.from_documents(
    documents,
    transformations=[SentenceSplitter(chunk_size=300, chunk_overlap=30)],
)
print(f"Documents: {len(documents)} pages, {len(index.docstore.docs)} chunks", flush=True)

qa_prompt = PromptTemplate(
    "You are the Airport Operations Assistant.\n"
    "Answer using ONLY the context below.\n"
    "Cite the document number and section for every rule, for example [GIA-POL-01, 2.3].\n"
    "If the context does not contain the answer, say exactly: I could not find this in the documents.\n"
    "Keep the answer under 120 words.\n\n"
    "Context:\n{context_str}\n\n"
    "Question: {query_str}\n"
    "Answer: "
)
policy_engine = index.as_query_engine(similarity_top_k=3, text_qa_template=qa_prompt)

policy_tool = QueryEngineTool.from_defaults(
    query_engine=policy_engine,
    name="airport_policy",
    description=(
        "Use this tool for questions about airport RULES: service standards, waiting-time limits, "
        "minimum number of counters, escalation levels, what the duty manager must do, smart gates. "
        "Sources: GIA-POL-01 Passenger Service Standards Policy and GIA-SOP-06 Peak-Period Operations and Queue Escalation SOP. "
        "Input: a plain-language question. Output: an answer with document number and section."
    ),
)

# ------------------------------------------------------------------ tool 2: SQL on data/airport_ops.zip
if not DB_PATH.exists():
    with zipfile.ZipFile(DB_ZIP) as z:
        name = next(n for n in z.namelist() if n.endswith(".db"))
        DB_PATH.write_bytes(z.read(name))
print(f"Database: {DB_PATH} ({DB_PATH.stat().st_size / 1_000_000:.1f} MB)", flush=True)

con = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True, check_same_thread=False)   # read-only


def query_airport_database(sql: str) -> str:
    """Run one read-only SELECT query on the airport database and return the result as text."""
    text = sql.strip().rstrip(";")
    if not text.lower().startswith(("select", "with")) or ";" in text:
        return "Error: only a single SELECT query is allowed."
    try:
        df = pd.read_sql_query(text, con)
    except Exception as e:
        return f"SQL error: {e}. Check the table and column names and try again."
    if df.empty:
        return "The query returned no rows."
    note = f"\n(first 30 of {len(df)} rows shown)" if len(df) > 30 else ""
    return df.head(30).to_string(index=False) + note


SQL_DESCRIPTION = """
Use this tool for questions about measured NUMBERS: waiting times, counters open, flights, delays, feedback, missed flights.
Input: ONE SQLite SELECT query. Output: the result rows as text.

Tables and views:
- v_departure_immigration_hourly (easiest for waits and counters): journey_date, weekday, immigration_hour, terminal_id,
  sampled_journeys, avg_wait_min, pct_over_30_min, counters_open
- passenger_journeys (4 percent sample of passengers): journey_date, weekday, immigration_hour, direction ('Departure'/'Arrival'),
  terminal_id ('T1'/'T2'), check_in_wait_min, security_wait_min, immigration_wait_min, baggage_wait_min, missed_flight (0/1), spend_aed
- staffing_roster: roster_date, hour, checkpoint_id (for example 'T1-IMM-DEP'), counters_open, staff_on_shift
- dim_checkpoints: checkpoint_id, terminal_id, counters_installed, standard_peak_counters, standard_offpeak_counters
- dim_date: date_key, weekday    (join staffing_roster.roster_date = dim_date.date_key to get the weekday)
- flights: flight_date, weekday, airline_code, route_code, terminal_id, direction, passengers, delay_min, status
- v_airline_month_delay: year_month, airline_name, flights, delayed_flights, delayed_pct
- feedback: weekday, hour, terminal_id, category, score (1 to 5)

Rules: peak hours are 17:00 to 22:59 (immigration_hour 17 to 22). weekday values are names like 'Friday'.
passenger_journeys is a 4 percent sample: averages and percentages are fine, multiply counts by 25.
"""

sql_tool = FunctionTool.from_defaults(fn=query_airport_database, name="airport_database", description=SQL_DESCRIPTION)

# ------------------------------------------------------------------ the agent
SYSTEM_PROMPT = (
    "You are the Airport Operations Assistant.\n"
    "You have two tools: airport_policy (the rules) and airport_database (the measured numbers).\n"
    "- For a question about a rule or a procedure, use airport_policy.\n"
    "- For a question about numbers, use airport_database.\n"
    "- For a question that compares reality with a rule, use BOTH tools.\n"
    "Give the rule with its document and section, and the numbers you got from the database.\n"
    "Never invent a number. If neither tool has the answer, say exactly: I could not find this.\n"
    "Peak hours are 17:00 to 22:59. Keep the answer under 150 words."
)

agent = FunctionAgent(tools=[policy_tool, sql_tool], llm=llm, system_prompt=SYSTEM_PROMPT)


async def ask_agent(question):
    """Run the agent. Return the answer and the list of tool calls it made."""
    handler = agent.run(question)
    calls = []
    async for event in handler.stream_events():
        if isinstance(event, ToolCall):
            calls.append(f"{event.tool_name}  {event.tool_kwargs}")
    response = await handler
    return str(response), calls


# ------------------------------------------------------------------ Gradio page
async def answer_question(question):
    if not question or not question.strip():
        return "Please type a question.", ""
    try:
        answer, calls = await ask_agent(question)
    except Exception as e:
        return f"Something went wrong: {e}", ""
    tools_used = "\n".join(f"{i}. {c}" for i, c in enumerate(calls, start=1)) or "No tool was used."
    return answer, tools_used


with gr.Blocks(title="Airport Operations Assistant") as demo:
    gr.Markdown("## Airport Operations Assistant\nAsk about airport rules, airport data, or both.")
    question_box = gr.Textbox(label="Your question", placeholder="For example: Is Terminal 1 meeting the immigration standard on Friday evenings?")
    ask_button = gr.Button("Ask")
    answer_box = gr.Textbox(label="Answer", lines=8)
    tools_box = gr.Textbox(label="Tools the agent used", lines=8)
    gr.Examples(
        examples=[
            "What must the duty manager do above 20 minutes?",
            "Which airline has the highest delayed-flight percentage?",
            "Is Terminal 1 meeting the departure immigration standard on Friday evenings?",
            "What is the daily parking tariff?",
        ],
        inputs=question_box,
    )
    ask_button.click(answer_question, question_box, [answer_box, tools_box])
    question_box.submit(answer_question, question_box, [answer_box, tools_box])

if __name__ == "__main__":
    demo.queue(default_concurrency_limit=2)
    demo.launch(
        server_name="0.0.0.0",
        server_port=PORT,
        auth=("workshop", APP_PASSWORD) if APP_PASSWORD else None,
        show_error=True,
    )
